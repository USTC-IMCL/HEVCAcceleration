import numpy as np
import tensorflow as tf
import tensorlayer as tl
import h5py
import random
from model import net64, net32, net16, net8
import argparse

parser = argparse.ArgumentParser(description='Train or test neural network')
parser.add_argument('--train', dest='train', action='store_true', default=True)
parser.add_argument('--test', dest='train', action='store_false', default=False)
parser.add_argument('--size', dest='size', action='store', default=64, type=int)
parser.add_argument('--qp', dest='QP', action='store', default=22, type=int)
parser.add_argument('--data', dest='data_dir', action='store', default='./')
parser.add_argument('--model', dest='model_dir', action='store', default='./')
parser.add_argument('--seq', dest='seq_name', action='store', default='./')
parser.add_argument('--device', dest='device', action='store', default=1, type=int)
args = parser.parse_args()

def get_train_data(dir, qp, size):
    train_data = np.zeros((500000, size, size, 1), dtype=np.uint8)        #generate the fake data
    train_label = np.zeros((500000, ), dtype=np.int)      #using this code, please modify this part with the data in your system
    val_data = np.zeros((50000, size, size, 1), dtype=np.uint8)
    val_label = np.zeros((50000, ), dtype=np.int)
    return train_data, train_label, val_data, val_label

def get_test_data(dir, qp, size):
    test_data = np.zeros((500000, size, size, 1))        #generate the fake data
    return test_data

device = args.device
if device == 0:
    os.environ['CUDA_VISIBLE_DEVICES'] = '' # GPU is disabled
    sess = tf.Session()
elif device == 1:
    tl.ops.set_gpu_fraction(sess=None, gpu_fraction=0.2)
    sess = tf.InteractiveSession()
elif device == 2:
    sess = tf.Session()

if args.size == 64:
    model = net64(args.QP)
elif args.size == 32:
    model = net32(args.QP)
elif args.size == 16:
    model = net16(args.QP)
elif args.size == 8:
    model = net8(args.QP)

if args.train:
    train_data, train_label, val_data, val_label = get_train_data(args.data_dir, args.QP, args.size)
    model.build_net(sess)
    model.train_net(train_data, train_label, val_data, val_label, sess, args.model_dir)

if not args.train:
    test_data = get_test_data(args.data_dir, args.QP, args.size)
    model.build_net(sess)
    model.test_net(test_data, sess, args.model_dir, args.seq_name)




