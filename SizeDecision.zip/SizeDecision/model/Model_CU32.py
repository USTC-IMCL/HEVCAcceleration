import numpy as np
import tensorflow as tf
import tensorlayer as tl
import h5py
import random


CU_SIZE = 32
INPUT_CHANNELS = 1
NUM_CONV11_FILTERS = 8
NUM_CONV12_FILTERS = 4
NUM_CONV13_FILTERS = 4
NUM_CONV2__FILTERS_INPUT = NUM_CONV11_FILTERS + NUM_CONV12_FILTERS + NUM_CONV13_FILTERS
NUM_CONV2__FILTERS_OUPUT = NUM_CONV2__FILTERS_INPUT * 2
NUM_CONV3__FILTERS_INPUT = NUM_CONV2__FILTERS_OUPUT
NUM_CONV3__FILTERS_OUPUT = NUM_CONV3__FILTERS_INPUT
NUM_FC1_NODES = 96
NUM_FC2_NODES = 16
NUM_FC3_NODES = 2
BATCH_SIZE = 64
NUM_EPOCHS_PER_DECAY = 50

class net32(object):
    def __init__(self, QP):
        self.QP = QP

    def build_net(self, sess):
        self.x_ = tf.placeholder(tf.float32, shape=[BATCH_SIZE, CU_SIZE, CU_SIZE, INPUT_CHANNELS])
        self.y_ = tf.placeholder(tf.int64, shape=[BATCH_SIZE, ])
        network = tl.layers.InputLayer(self.x_, name='input')
        netbranch1 = tl.layers.Conv2dLayer(network,
                                         act=lambda x: tl.act.lrelu(x, 0.25),
                                         shape=[5, 5, INPUT_CHANNELS, NUM_CONV11_FILTERS],  # 8 features for each 5x5 patch
                                         strides=[1, 2, 2, 1],
                                         padding='SAME',
                                         name='cnn11')  #output: (?, 16, 16, 8)

        netbranch2 = tl.layers.Conv2dLayer(network,
                                         act=lambda x: tl.act.lrelu(x, 0.25),
                                         shape=[7, 3, INPUT_CHANNELS, NUM_CONV12_FILTERS],  # 4 features for each 7x3 patch
                                         strides=[1, 2, 2, 1],
                                         padding='SAME',
                                         name='cnn21')  # output: (?, 16, 16, 4)

        netbranch3 = tl.layers.Conv2dLayer(network,
                                         act=lambda x: tl.act.lrelu(x, 0.25),
                                         shape=[3, 7, INPUT_CHANNELS, NUM_CONV13_FILTERS],  # 4 features for each 3x7 patch
                                         strides=[1, 2, 2, 1],
                                         padding='SAME',
                                         name='cnn31')  # output: (?, 16, 16, 4)

        network = tl.layers.ConcatLayer([netbranch1, netbranch2, netbranch3], 3, name='concat_layer')

        network = tl.layers.Conv2dLayer(network,
                                        act=lambda x: tl.act.lrelu(x, 0.25),
                                        shape=[3, 3, NUM_CONV2__FILTERS_INPUT, NUM_CONV2__FILTERS_OUPUT],
                                        strides=[1, 2, 2, 1],
                                        padding='SAME',
                                        name='cnn2')  # output: (?, 8, 8, 32)
        network = tl.layers.Conv2dLayer(network,
                                        act=lambda x: tl.act.lrelu(x, 0.25),
                                        shape=[3, 3, NUM_CONV3__FILTERS_INPUT, NUM_CONV3__FILTERS_OUPUT],
                                        strides=[1, 2, 2, 1],
                                        padding='VALID',
                                        name='cnn3')  # output: (?, 3, 3, 32)

        network = tl.layers.FlattenLayer(network, name='flatten')  # 288
        network = tl.layers.DenseLayer(network, n_units=NUM_FC1_NODES,
                                       act=lambda x: tl.act.lrelu(x, 0.25), name='relu1')
        network = tl.layers.DropoutLayer(network, keep=0.5, name='drop1')
        network = tl.layers.DenseLayer(network, n_units=NUM_FC2_NODES,
                                       act=lambda x: tl.act.lrelu(x, 0.25), name='relu2')
        network = tl.layers.DropoutLayer(network, keep=0.5, name='drop2')
        self.network = tl.layers.DenseLayer(network, n_units=NUM_FC3_NODES,
                                       act=lambda x: tl.act.lrelu(x, 0.25), name='output')    # entry for network
        self.y = network.outputs

        tl.layers.initialize_global_variables(sess)
        self.network.print_params()
        self.network.print_layers()

        self.cost = tl.cost.cross_entropy(self.y, self.y_, name='cost')
        self.correct_prediction = tf.equal(tf.argmax(self.y, 1), self.y_)
        self.acc = tf.reduce_mean(tf.cast(self.correct_prediction, tf.float32))
        self.y_op = tf.argmax(tf.nn.softmax(self.y), 1)


    def train_net(self, X_train, y_train, X_val, y_val, sess, save_path):
        self.X_train = X_train
        self.y_train = y_train
        self.X_val = X_val
        self.y_val = y_val
        self.train_samples = np.shape(X_train)[0]
        self.val_samples = np.shape(X_val)[0]
        train_params = self.network.all_params
        #decay_steps = int(self.train_samples / BATCH_SIZE * NUM_EPOCHS_PER_DECAY)
        #learning_rate = tf.train.exponential_decay(learning_rate=0.1, decay_steps=decay_steps, decay_rate=0.1, staircase=True)
        #train_params = self.network.all_params
        train_op1 = tf.train.AdamOptimizer(0.005).minimize(self.cost)
        train_op2 = tf.train.AdamOptimizer(0.0005).minimize(self.cost)
        train_op3 = tf.train.AdamOptimizer(0.00005).minimize(self.cost)
        tl.layers.initialize_global_variables(sess)
        tl.utils.fit(sess, self.network, train_op1, self.cost, self.X_train, self.y_train, self.x_, self.y_, acc=self.acc, batch_size=BATCH_SIZE,
                     n_epoch=50, print_freq=1, X_val=self.X_val, y_val=self.y_val, eval_train=True)
        l.utils.fit(sess, self.network, train_op2, self.cost, self.X_train, self.y_train, self.x_, self.y_,
                    acc=self.acc, batch_size=BATCH_SIZE,
                    n_epoch=50, print_freq=1, X_val=self.X_val, y_val=self.y_val, eval_train=True)
        l.utils.fit(sess, self.network, train_op3, self.cost, self.X_train, self.y_train, self.x_, self.y_,
                    acc=self.acc, batch_size=BATCH_SIZE,
                    n_epoch=50, print_freq=1, X_val=self.X_val, y_val=self.y_val, eval_train=True)

        self.saver = tf.train.Saver(train_params)
        self.saver.save(sess, save_path + str(self.QP) + '_32.ckpt')

    def test_net(self, X_test, sess, model_path, seq_name, th=0.5):
        self.X_test = X_test
        self.saver = tf.train.Saver()
        self.saver.restore(sess, model_path + str(self.QP) + '_' + str(CU_SIZE) + '.ckpt')
        block_num = self.X_test.shape[0]
        test_batch = 1000
        output = np.zeros((block_num, 2))
        for i in range(int(block_num / test_batch)):
            batch_x = self.X_test[i * test_batch:test_batch * (i + 1)]
            feed_dict = {x_: batch_x}
            feed_dict.update(dp_pict)
            output[i * test_batch:(i + 1) * test_batch] = sess.run(self.y, feed_dict=feed_dict)
        save_name = seq_name + str(CU_SIZE) + '.txt'
        fod = open(save_name, 'w')
        for i in range(block_num):
            if np.max(output[i, :] > th):
                fod.write('%d\n' % (np.argmax(output[i, :])))
            else:
                fod.write('2\n')


if __name__ == '__main__':
    print("Training code for partition of CU 32x32.")

